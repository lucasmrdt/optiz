OUTPUT_DIR = "output"
INPUT_DIR = "input"
DEBUG_DIR = "debug"
